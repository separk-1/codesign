# Data Quality Summary

## Package Inventory

- Normalized XML P&ID inputs: 35 files in `source_pids_xml/`.
- pyDEXPI JSON exports: 35 files in `pyDEXPI_json/`.
- GEXF graph exports: 30 files in `knowledge_graph_gexf/`.
- SQLite database: `database/pid_kg.sqlite`.
- Schemas: 3 files in `schemas/`.
- Sample decision logs: 3 CSV files in `design_decision_logs/`, including one human-confirmed sample, one AI-agent assumption sample, and one scenario-variation example set.
- Sample candidate graph exports: 2 JSON files in `candidate_graphs/`.

## Known Limitations

1. The pyDEXPI JSON files are the primary derived representation. They preserve richer DEXPI structure than the GEXF exports.
2. Some GEXF files contain no graph nodes or limited graph content. This reflects current conversion/serialization limitations and sparse source structures, not absence of the original JSON model.
3. Some source examples contain sparse labels, repeated tags, or incomplete connectivity references. This affects graph readability and retrieval quality.
4. Candidate graph exports are decision-annotated research artifacts. They are not standards-certified DEXPI XML write-backs and should not be treated as approved engineering P&ID drawings.
5. AI-agent decision logs and scenario-generated decision examples are assumptions/examples for review, not verified engineering decisions.
6. The decision-log files are demonstration datasets for traceability and schema validation. They should not be interpreted as a full user-study dataset.
