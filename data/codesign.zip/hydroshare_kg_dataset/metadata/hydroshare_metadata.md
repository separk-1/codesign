# HydroShare Metadata Draft

## Title

DEXPI-Derived P&ID Knowledge Graph and Decision Traceability Dataset

## Creator

Seongeun Park

## Abstract

This dataset contains derived P&ID knowledge graph artifacts prepared from public DEXPI TrainingTestCases examples. It includes normalized DEXPI/Proteus XML inputs, pyDEXPI JSON model exports, GEXF graph exports where available, a SQLite database representation, schema documentation, sample design decision logs, a scenario-variation decision-log example set, and sample decision-generated candidate graph exports. The dataset supports research on P&ID knowledge representation, GraphRAG, human-AI design communication, and traceable design-decision logging. The candidate graph files are research artifacts and are not final approved engineering P&ID drawings.

## Keywords

Hydroinformatics; P&ID; DEXPI; pyDEXPI; knowledge graph; GraphRAG; decision log; human-AI collaboration; process systems; design traceability

## Source

Original upstream dataset: DEXPI **Public Example PIDs / TrainingTestCases**

- Repository: https://gitlab.com/dexpi/TrainingTestCases
- DEXPI 1.3 example PIDs: https://gitlab.com/dexpi/TrainingTestCases/-/tree/master/dexpi%201.3/example%20pids?ref_type=heads

The original P&ID examples were not authored by this project. This dataset contains derived and normalized research artifacts generated from the public DEXPI examples.

## Related Resource

GitHub repository for software prototype, transformation scripts, GraphRAG endpoint, and web application: https://github.com/separk-1/codesign
