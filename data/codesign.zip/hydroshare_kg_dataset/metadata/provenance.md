# Source and Provenance

## Upstream Source

The source P&ID examples are based on the public DEXPI repository **Public Example PIDs / TrainingTestCases**.

- Repository: https://gitlab.com/dexpi/TrainingTestCases
- DEXPI 1.3 example PIDs: https://gitlab.com/dexpi/TrainingTestCases/-/tree/master/dexpi%201.3/example%20pids?ref_type=heads

This package does not claim authorship of the original P&ID examples. It provides derived and normalized research artifacts created from those public examples.

## What This Package Contains

This HydroShare package contains derived and normalized research artifacts prepared from those public DEXPI examples:

- normalized DEXPI/Proteus XML P&ID inputs,
- pyDEXPI JSON model exports,
- GEXF graph exports where conversion was successful,
- a SQLite database representation extracted from the pyDEXPI JSON files,
- lightweight schemas,
- sample decision logs,
- sample decision-generated candidate graph exports.

## Use Limitation

These artifacts are for research on P&ID knowledge representation, GraphRAG, and AI-mediated design decision traceability. They are not final approved engineering drawings.
