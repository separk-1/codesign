# HydroShare Data Package

This folder contains the data package prepared for HydroShare release. It is organized around derived P&ID knowledge graph artifacts and decision-traceability examples created from public DEXPI TrainingTestCases data.

## Contents

- `source_pids_xml/`: 35 normalized DEXPI/Proteus XML P&ID inputs.
- `pyDEXPI_json/`: 35 pyDEXPI JSON model exports. This is the primary derived representation.
- `knowledge_graph_gexf/`: 30 GEXF graph exports for graph-analysis tools such as Gephi and NetworkX. Some files are sparse or empty due to current conversion limitations.
- `database/`: `pid_kg.sqlite`, a SQLite representation of equipment, nozzles, lines, and connections extracted from the pyDEXPI JSON files.
- `schemas/`: lightweight schemas for the knowledge graph, decision log, and candidate graph export formats.
- `design_decision_logs/`: sample human, AI-agent, and scenario-variation decision logs.
- `candidate_graphs/`: sample decision-generated candidate P&ID graph exports.
- `metadata/`: provenance, data quality notes, and HydroShare metadata draft.
- `manifest.csv`: file inventory for upload checking.

## Source

Original upstream dataset: DEXPI **Public Example PIDs / TrainingTestCases**

- Repository: https://gitlab.com/dexpi/TrainingTestCases
- DEXPI 1.3 example PIDs: https://gitlab.com/dexpi/TrainingTestCases/-/tree/master/dexpi%201.3/example%20pids?ref_type=heads

This HydroShare package contains derived and normalized research artifacts. It does not claim authorship of the original DEXPI P&ID examples.

## Use Note

These files are research data artifacts for P&ID knowledge representation, GraphRAG, and human-AI design traceability. Candidate graph files are not final approved engineering P&ID drawings.
